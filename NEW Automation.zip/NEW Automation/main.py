from newspaper import Article
from gnews import GoogleNews
import nltk
from firefox import UploadArticle
from summary import GetSummary


class MAINCLASS():
    """
    """

    def FormattedArticle(self, data, imgurl, blog):
        count = 0
        arrr = ''
        for line in data.split('\n'):
            count += 1
            if count == 1:
                img = f"""
                    <div class="separator" style="clear: both;"><a href="{imgurl}" style="display: block; padding: 1em 0; text-align: center; clear: left; float: left; margin:0 0.7rem;"><img alt="" border="0" width="400" data-original-height="400" data-original-width="650" src="{imgurl}"/></a></div>
                """
                arrr += img
            lines = f"<p>{line}</p>"
            arrr += lines
        arrr += f'<div> <a href="{blog}">Blog Credit/Source. </a> </div>'
        return arrr

    def __init__(self, country='IN'):
        ArtileList = []
        gn = GoogleNews(country)
        top = gn.top_news()
        nltk.download('punkt')
        entries = top["entries"]
        count = 0
        for url in entries:
            try:
                url = url['link']
                article = Article(url)
                article.download()
                article.parse()
                article.nlp()
                article.clean_doc
                topimg = article.top_image
                title = article.title
                fullarticle = GetSummary(url)
                if fullarticle:
                    FullArticle = self.FormattedArticle(
                        fullarticle, topimg, url)
                    ArtileList.append([title, FullArticle])
                    count += 1
            except:
                pass
            if count == 3:
                break
        UploadArticle('v8f3iirf.shahid', ArtileList)


# MAINCLASS('US')
