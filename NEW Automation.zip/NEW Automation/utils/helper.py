from bs4 import BeautifulSoup
import itertools


def xpath_soup(element):
    components = []
    child = element if element.name else element.parent
    for parent in child.parents:
        previous = itertools.islice(
            parent.children, 0, parent.contents.index(child))
        xpath_tag = child.name
        xpath_index = sum(1 for i in previous if i.name == xpath_tag) + 1
        components.append(
            xpath_tag if xpath_index == 1 else "%s[%d]" % (
                xpath_tag, xpath_index)
        )
        child = parent
    components.reverse()
    return "/%s" % "/".join(components)


def getTitleXpath(page):
    soup = BeautifulSoup(page, "lxml")
    elem = soup.find_all("input")
    for i in elem:
        item = i.get("aria-label")
        if item == "Title":
            return xpath_soup(i)

    return None


def getConfirmbtn(page):
    soup = BeautifulSoup(page, "lxml")
    soup = soup.find_all('div')
    xpath = None
    for i in soup:
        item = i.get('role')
        if item == 'button':
            soup2 = i.find_all('span')
            for s in soup2:
                if s.text == 'Confirm':
                    xpath = xpath_soup(i)
    return xpath


def createNewPost(page):
    soup = BeautifulSoup(page, "lxml")
    elem = soup.find_all("div")
    for i in elem:
        item = i.get("aria-label")
        if item == "Create New Post":
            return xpath_soup(i)
    return None


def publishBtn(page):
    soup = BeautifulSoup(page, "lxml")
    elem = soup.find_all("div")
    xpath = None
    for i in elem:
        item = i.get("aria-label")
        if item == "Publish":
            xpath = xpath_soup(i)

    return xpath


def PostContentXpath(page):
    soup = BeautifulSoup(page, "lxml")
    elem = soup.find_all("textarea")
    for i in elem:
        wrap = i.get('wrap')  # off
        spellchck = i.get('spellcheck')  # false
        autocorrct = i.get('autocorrect')  # off
        if wrap == "off" and spellchck == "false" and autocorrct == "off":
            return xpath_soup(i)
    # <textarea style="position: absolute; bottom: -1em; padding: 0px; width: 1px; height: 1em; min-height: 1em; outline: none;" autocorrect="off" autocapitalize="none" spellcheck="false" tabindex="0" wrap="off"></textarea>
