from selenium import webdriver
from selenium.webdriver.common.by import By
import os
from selenium.webdriver.common.keys import Keys
import time
import random
from pytube import Channel
import shutil
from pytube import YouTube
from bs4 import BeautifulSoup
import requests
import json
import gc
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from webdriver_manager.firefox import GeckoDriverManager
from selenium.webdriver import DesiredCapabilities
from selenium.webdriver.firefox.service import Service
import itertools
from selenium.webdriver import ActionChains
from utils.helper import getTitleXpath, createNewPost, PostContentXpath, publishBtn, getConfirmbtn


def xpath_soup(element):
    components = []
    child = element if element.name else element.parent
    for parent in child.parents:
        previous = itertools.islice(
            parent.children, 0, parent.contents.index(child)
        )
        xpath_tag = child.name
        xpath_index = sum(1 for i in previous if i.name == xpath_tag) + 1
        components.append(
            xpath_tag
            if xpath_index == 1
            else "%s[%d]" % (xpath_tag, xpath_index)
        )
        child = parent
    components.reverse()
    return "/%s" % "/".join(components)


def UploadArticle(profile, articles):
    desired = DesiredCapabilities.FIREFOX
    User_Agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0"
    ffservice = Service(GeckoDriverManager().install())
    ffOptions = Options()
    ffOptions.add_argument("--mute-audio")
    ffOptions.add_argument(f"user-agent={User_Agent}")
    ffOptions.add_argument("--disable-extensions")
    ffOptions.add_argument("--start-maximized")
    ffOptions.set_preference("media.volume_scale", "0.0")
    ffOptions.add_argument(
        '--disable-blink-features=AutomationControlled')
    ffOptions.binary_location = r"C:\Program Files\Mozilla Firefox\firefox.exe"
    ffOptions.add_argument("-enable-automation")
    ffOptions.set_preference("dom.webdriver.enabled", False)
    ffOptions.set_preference('useAutomationExtension', False)

    ffOptions.add_argument("-profile")
    ffOptions.add_argument(
        f'C:\\Users\\shaik\\AppData\\Roaming\\Mozilla\\Firefox\\Profiles\\{profile}')
    ffOptions.set_preference('devtools.jsonview.enabled', False)
    driver = webdriver.Firefox(service=ffservice, options=ffOptions)
    for article in articles:
        driver.get("https:blogger.com")
        time.sleep(2)
        driver.find_element(
            By.XPATH, createNewPost(driver.page_source)).click()
        time.sleep(6)
        driver.find_element(
            By.XPATH, getTitleXpath(driver.page_source)).send_keys(article[0])
        time.sleep(2)
        postbtn = PostContentXpath(driver.page_source)
        d = driver.find_element(By.XPATH, postbtn)
        ActionChains(driver).click(d).send_keys(str(article[1])).perform()
        time.sleep(10)
        driver.switch_to.default_content()
        time.sleep(3)
        pubbtn = publishBtn(driver.page_source)
        driver.find_element(
            By.XPATH, pubbtn).click()
        driver.find_element(
            By.XPATH, getConfirmbtn(driver.page_source)).click()
        time.sleep(4)
