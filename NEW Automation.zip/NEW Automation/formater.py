

def formater(imgurl, blog, summary, source="https://news.google.com/"):
    return f"""
    <div class="separator" style="clear: both;"><a href="{imgurl}" style="display: block; padding: 1em 0; text-align: center; clear: left; float: left; margin:0 0.7rem;"><img alt="" border="0" width="400" data-original-height="400" data-original-width="650" src="{imgurl}"/></a></div>
{blog}
<h1>Summary</h1>
<b> {summary}
</b>
<br>
<a href="{source}" target="_blank">Credit</a>
"""
