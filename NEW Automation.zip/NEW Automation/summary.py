
import openai


def GetSummary(url):
    api = "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"
    # openai.api_key = "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"
    openai.api_key = api
    try:
        response = openai.Completion.create(
            engine='text-davinci-003',
            prompt=f"make article summary, reply only with summary: {url}",
            temperature=0,
            max_tokens=1000,
            top_p=1.0,
            frequency_penalty=0.0,
            presence_penalty=0.0,
        )
        response = (response["choices"][0]["text"])
        return response
    except Exception as d:
        pass
